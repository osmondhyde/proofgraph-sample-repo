# ProofGraph Sample Repository

This repository exists solely to test the ProofGraph verification engine.

It includes:
- Multiple folders
- Different file types (JS, JSX, API)
- A simple architecture that allows ProofGraph to track authorship and code structure

You can add commits, change files, and push updates to see how ProofGraph generates forensic results.
