export function getUser(id) {
  return {
    id,
    name: "Test User",
    role: "Developer"
  };
}
