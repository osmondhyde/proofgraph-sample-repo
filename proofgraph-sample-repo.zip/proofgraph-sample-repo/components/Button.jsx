export default function Button({ label }) {
  return <button>{label}</button>;
}
