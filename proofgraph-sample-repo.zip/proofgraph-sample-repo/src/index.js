import { add, greet } from "./utils.js";

console.log("ProofGraph test repo loaded");
console.log(add(5, 7));
console.log(greet("Osmond"));
