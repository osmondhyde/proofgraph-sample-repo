export function add(a, b) {
  return a + b;
}

export function greet(name) {
  return `Hello ${name}, ProofGraph is working`;
}
